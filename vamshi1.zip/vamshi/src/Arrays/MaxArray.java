package Arrays;

public class MaxArray {

	public static int LargestElement(int[] num) {
		int n=num.length;
		int max=num[0];
		for(int i=0;i<n;i++) {
			if(num[i]>max)
				max=num[i];
		}
		return max;
	}
	public static void main(String[] args) {
		int[] arr= {5,8,9,2,3,4};
		System.out.println(("largest number is :"+LargestElement(arr)));
	}
}
