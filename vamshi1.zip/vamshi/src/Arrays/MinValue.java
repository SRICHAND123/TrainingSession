package Arrays;

public class MinValue {

		public static int MinElement(int[] num) {
			int n=num.length;
			int min=num[0];
			for(int i=0;i<n;i++) {
				if(num[i]<min)
					min=num[i];
			}
			return min;
		}
		public static void main(String[] args) {
			int[] arr= {5,8,9,2,3,4};
			System.out.println(("Min number is :"+MinElement(arr)));
		}
	}

	


