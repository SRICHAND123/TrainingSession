package SumOfNumbers;

import java.util.Scanner;

public class LeafYear {

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		int n=sc.nextInt();
		
		if((n%4==0 && n%100!=0) || n%400==0){
			System.out.println("this year is leaf year");
		}else {
			System.out.println("this year is not a leaf year");
		}

		sc.close();	
	}

}
