package SumOfNumbers;

import java.util.Scanner;

public class tech {

	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);
		
		System.out.println("enter a number:");
		int a = sc.nextInt();
		
		System.out.println("user roll number:" +a);
		
System.out.println("this is java session");
		System.out.println("for batch2");
	}

}
