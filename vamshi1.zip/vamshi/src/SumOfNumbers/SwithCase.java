package SumOfNumbers;

import java.util.Scanner;

public class SwithCase {

	public static void main(String[] args) {
		Scanner sc =new Scanner(System.in);
		int a=sc.nextInt();
		int b=sc.nextInt();
		char op=sc.next().charAt(0);
		
	}

}
