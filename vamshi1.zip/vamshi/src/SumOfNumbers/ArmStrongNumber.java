package SumOfNumbers;
import java.util.Scanner;
public class ArmStrongNumber {

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		System.out.println("enter the n value :");
		int n=sc.nextInt();
		int original = n;
		int sum=0;
		int digits=String.valueOf(n).length();
		while(n>0) {
			int digit=n%10;
			sum+=Math.pow(digit, digits);
			n=n/10;
		}
		if(sum==original)
			System.out.println("the given number is armstromg number");
		else
			System.out.println("not a armstrong number");
		
	}

}
