package SumOfNumbers;

import java.util.Scanner;

public class PercentageOFStudents {

	public static void main(String[] args) {
		Scanner sc =new Scanner(System.in);
		int n1=sc.nextInt();
		int n2=sc.nextInt();
		int n3=sc.nextInt();
		int n4=sc.nextInt();
		int n5=sc.nextInt();
		
		int sum=n1+n2+n3+n4+n5;
		int percentage=((sum)/5);
		System.out.println("percentage is :");
		
		if(percentage>=90)
			System.out.println("Grade is A");
		else if(percentage>=80 && percentage<=90)
			System.out.println("Grade is B");
		else if(percentage>=60 && percentage<=80)
			System.out.println("Grade is C");
		else
			System.out.println("Grade is D");


	}

}
