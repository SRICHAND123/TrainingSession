package SumOfNumbers;

import java.util.Scanner;


public class SumOfNnaturalNumbers {

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		System.out.println("enter the n value :");
		int sum=0;
		int n=sc.nextInt();
		for(int i=0;i<=n;i++) {
			sum+=i;
		}
		System.out.println(sum);
			
	}

}
