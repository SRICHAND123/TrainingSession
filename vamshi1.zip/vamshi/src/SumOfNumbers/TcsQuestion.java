package SumOfNumbers;

import java.util.Scanner;


public class TcsQuestion {

	public static void main(String[] args) {
		int a=5,b=2,c;
		
		c=a++ + b++;
		System.out.println(a+ " "+b+ " " +c+ " " );
		}
	}

	
