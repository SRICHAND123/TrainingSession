package String;

import java.util.Arrays;

public class AnagramString {
	public static boolean isAnagram(String s,String t) {
		char[] arr=s.toCharArray();
		char[] arr1=t.toCharArray();
		Arrays.sort(arr);
		Arrays.sort(arr1);
		if(Arrays.equals(arr,arr1)) {
			return true;
		}
		return false;
	}
	public static void main(String[] args) {
		String s="anagram";
		String t="nagaram";
		System.out.println(isAnagram(s,t));
	}

}
