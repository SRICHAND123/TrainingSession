package String;

public class ReverseString {

	public static void main(String[] args) {
		String s ="srichand";
		System.out.println(s.length());
	}

}
