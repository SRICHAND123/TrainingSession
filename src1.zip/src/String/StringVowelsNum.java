package String;

public class StringVowelsNum {

	public static void main(String[] args) {
		
	}

}
