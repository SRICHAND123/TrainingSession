package Strings;

public class String1 {

	public static void main(String[] args) {
		String s1 = new String("spring");
		s1.concat("fail");
		String s2 = s1.concat("winter");
		s2.concat("summer");
		String s3 = s2.concat("rainy");
		s3.concat("snow");
		String s4 = s3.concat("snow"); 
		System.out.println(s1);
		System.out.println(s2);
		System.out.println(s3);
		System.out.println(s4);
	}

}
