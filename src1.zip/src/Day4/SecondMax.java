package Day4;

public class SecondMax {

	public static void main(String[] args) {
		int[] arr = {1,3,5,7,9,2,4,6,7,8};
		int max=Integer.MIN_VALUE;
		int smax=Integer.MIN_VALUE;
		for(int i=0;i<arr.length;i++) {
			if(arr[i]>max && arr[i]!=max)
				smax=arr[i];
		}
		System.out.println(smax);
	}

}
