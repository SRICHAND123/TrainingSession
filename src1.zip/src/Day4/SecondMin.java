package Day4;

public class SecondMin {

	public static void main(String[] args) {
		int[] arr= {1,3,5,7};
		int min=Integer.MAX_VALUE;
		int smin=Integer.MAX_VALUE;
		for(int i=0;i<arr.length;i++) {
			if(arr[i]<min && arr[i]!=min)
				smin=arr[i];
		}
		System.out.println(smin);
	}

}
