package addtwonumbers;

public class SustractionDriverClass {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		SubstractionClass a=new SubstractionClass();
		a.sub();
		Addition b=new Addition();
		b.add();
	}

}
