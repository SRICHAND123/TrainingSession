package addtwonumbers;

public class Addition {
void add() {
	int x=40 ,y=60;
	System.out.println("total :"+(x+y));
	System.out.println("total :"+(x-y));
}
}
