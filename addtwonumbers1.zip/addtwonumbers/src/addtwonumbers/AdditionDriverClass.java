package addtwonumbers;

public class AdditionDriverClass {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
Addition a=new Addition();
	a.add();
	SubstractionClass a=new SubstractionClass();
	a.sub();

	}

}
