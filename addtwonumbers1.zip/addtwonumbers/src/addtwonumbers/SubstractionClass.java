package addtwonumbers;

public class SubstractionClass {
	void sub() {
		int x=40 ,y=60;
		System.out.println("total :"+(x-y));
	}

}
